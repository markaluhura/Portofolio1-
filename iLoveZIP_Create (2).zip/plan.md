# plan.md

## 1. Objectives
- Deliver a premium, minimalist, monochrome, editorial personal brand landing page for **MARKALUHURA (Dymas Alfin)** with 9 sections and cohesive storytelling.
- Implement smooth motion + micro-interactions (framer-motion), typography-led layout, and rounded UI with subtle borders/shadows.
- Keep all content **hardcoded** in a single frontend config (`content.ts/js`) for easy edits; backend stays minimal (health only).
- Ensure CTAs work: **WhatsApp** (given link) + **mailto**; other socials as placeholders editable in config.

## 2. Implementation Steps

### Phase 1 — Core POC (Skipped)
- No external integrations, auth, uploads, or complex business logic. Build directly.

### Phase 2 — V1 App Development (Build all 9 sections) — STATUS: COMPLETE (tested via testing agent, iteration_1: 100% pass; back-to-top fix applied)
**User stories (V1)**
1. As a visitor, I can instantly understand Dymas’ multi-identity (economics/investing/creator/builder/athlete) from the hero section.
2. As a visitor, I can navigate to any section via a floating navbar that works on desktop and mobile.
3. As a visitor, I can scan selected work, filter by category, and open a project detail modal/page for more context.
4. As a visitor, I can explore current interests via an accordion with smooth animations and visual previews.
5. As a visitor, I can contact Dymas quickly via WhatsApp or email from multiple CTAs.

**Build steps**
1. **Project setup**
   - React + Tailwind + shadcn/ui + framer-motion.
   - Add font setup (Inter / Plus Jakarta Sans), global styles, grayscale image utilities.
   - Backend: FastAPI minimal `/api/health` only.
2. **Content architecture**
   - Create `src/content.ts` (or `content.js`) containing: hero copy, social links, work items, exploring accordion items, experience timeline items, seminars list, CTA links.
   - Keep all URLs (WhatsApp + mailto + placeholders) editable from this file.
3. **Design system primitives**
   - Tailwind tokens for palette (#111, #fff, #f7f7f7, #e5e5e5, #22c55e).
   - Reusable components: `SectionHeader`, `PillNav`, `Badge`, `WorkCard`, `Timeline`, `AccordionExploring`, `HoverPreview`.
4. **Section implementation (in order)**
   - (1) Floating pill navbar (status dot, anchor links, CTA, mobile hamburger).
   - (2) Hero “More Than One Thing”: oversized type + outlined layer, background watermark text, portrait cutout overlay, subtle scroll/parallax.
   - (3) /ABOUT: “I’VE NEVER REALLY BEEN JUST ONE THING.” + horizontal 5-chapter journey.
   - (4) /SELECTED WORK: filter pills + 2-col card grid + hover motion + “View All Work →” (modal/drawer or separate section).
   - (5) /CURRENTLY EXPLORING: animated accordion with expanded dark mode + preview image.
   - (6) /EXPERIENCE: dark bg timeline; hover reveals floating image card (use swimming + other assets).
   - (7) /ALWAYS LEARNING: horizontal scroll strip; include IDX seminar + campaign presentation + SIC sessions + Market Day.
   - (8) Philosophy: oversized typography, scroll-triggered reveal.
   - (9) Footer CTA: availability badge, WhatsApp + mailto CTAs, secondary social links, signature.
5. **Assets integration**
   - Add provided image URLs to content file and use in appropriate sections:
     - Headshot cutout → Hero portrait.
     - Swimming → COMPETE + Experience hover.
     - Scouts group + Presentation → Always Learning / Builder / SIC context.
   - Apply grayscale/contrast styling for consistent monochrome look.
6. **Accessibility + responsiveness**
   - Keyboard focus states, reduced-motion support, semantic headings.
   - Responsive layout: hero badges stack on mobile; work grid collapses to 1 column; navbar menu.
7. **Testing checkpoint (end of Phase 2)**
   - Run one full end-to-end UX pass: navigation anchors, filters, accordion, hover previews, CTAs, mobile layout.
   - Call testing agent to validate responsiveness, broken links, motion jitter, console errors.

### Phase 3 — Polish + Production Hardening — STATUS: NOT STARTED (only if user requests)
**User stories (Polish)**
1. As a visitor, I experience smooth, consistent motion without jank on scroll.
2. As a visitor, I can read all typography comfortably across screen sizes.
3. As a visitor, I see consistent hover/active states across interactive elements.
4. As a visitor, images load gracefully without layout shifts.
5. As a visitor, the site feels premium and cohesive end-to-end.

**Enhancements**
- Performance: lazy-load non-hero images, prefetch fonts, minimize re-renders.
- Motion refinement: staggered reveals, subtle parallax limits, reduced-motion fallback.
- Add optional project detail modal (if not already) with richer writeups for FLYFIN/Swakarya/SIC.
- Tighten copy and spacing; ensure monochrome consistency.
- Testing agent pass again (desktop + mobile).

### Phase 4 — Optional Extensions (Only if requested)
**User stories (Optional)**
1. As Dymas, I can update portfolio content without redeploying (CMS/admin).
2. As a visitor, I can download a one-page PDF profile.
3. As a visitor, I can view deeper case studies per project on dedicated routes.
4. As a visitor, I can switch between light/dark editorial themes.
5. As Dymas, I can track basic analytics events (CTA clicks) privately.

- If requested: add lightweight CMS (DB-backed), analytics, case-study routing, or dark-mode toggle.

## 3. Next Actions
1. Create `content.ts/js` with provided real items (FLYFIN, Swakarya, SIC, Market Day, IDX seminar, financial market campaign presentation) + placeholder socials.
2. Implement Phase 2 sections end-to-end with framer-motion + shadcn components.
3. Run testing agent on V1; fix issues.
4. Execute Phase 3 polish; run testing agent again.

## 4. Success Criteria
- All 9 sections implemented, responsive, and visually aligned with monochrome editorial direction.
- Navbar anchors + mobile hamburger work; filters/accordion/hover previews behave smoothly.
- WhatsApp link and mailto open correctly from hero + footer.
- No console errors; motion is smooth; content is editable via a single config file.
- Testing agent confirms end-to-end usability on desktop and mobile.