import requests
import sys

class BackendTester:
    def __init__(self, base_url="https://vibe-code-labs.preview.emergentagent.com"):
        self.base_url = base_url
        self.tests_run = 0
        self.tests_passed = 0
        self.failures = []

    def run_test(self, name, method, endpoint, expected_status, expected_keys=None):
        """Run a single API test"""
        url = f"{self.base_url}/{endpoint}"
        headers = {'Content-Type': 'application/json'}

        self.tests_run += 1
        print(f"\n🔍 Testing {name}...")
        print(f"   URL: {url}")
        
        try:
            if method == 'GET':
                response = requests.get(url, headers=headers, timeout=10)
            elif method == 'POST':
                response = requests.post(url, headers=headers, timeout=10)

            print(f"   Status: {response.status_code}")
            
            success = response.status_code == expected_status
            
            if success:
                try:
                    data = response.json()
                    print(f"   Response: {data}")
                    
                    # Check for expected keys if provided
                    if expected_keys:
                        for key in expected_keys:
                            if key not in data:
                                success = False
                                print(f"   ❌ Missing expected key: {key}")
                                self.failures.append(f"{name}: Missing key '{key}' in response")
                                break
                    
                    if success:
                        self.tests_passed += 1
                        print(f"   ✅ Passed")
                except Exception as e:
                    print(f"   ❌ Failed to parse JSON: {str(e)}")
                    self.failures.append(f"{name}: JSON parse error - {str(e)}")
                    success = False
            else:
                print(f"   ❌ Failed - Expected {expected_status}, got {response.status_code}")
                self.failures.append(f"{name}: Expected status {expected_status}, got {response.status_code}")

            return success

        except Exception as e:
            print(f"   ❌ Failed - Error: {str(e)}")
            self.failures.append(f"{name}: {str(e)}")
            return False

def main():
    print("=" * 60)
    print("MARKALUHURA BACKEND API TESTS")
    print("=" * 60)
    
    tester = BackendTester()

    # Test 1: GET /api/health
    tester.run_test(
        "Health Check",
        "GET",
        "api/health",
        200,
        expected_keys=["status"]
    )

    # Test 2: GET /api/
    tester.run_test(
        "Root API Endpoint",
        "GET",
        "api/",
        200,
        expected_keys=["message"]
    )

    # Print summary
    print("\n" + "=" * 60)
    print(f"📊 RESULTS: {tester.tests_passed}/{tester.tests_run} tests passed")
    print("=" * 60)
    
    if tester.failures:
        print("\n❌ FAILURES:")
        for failure in tester.failures:
            print(f"   - {failure}")
    else:
        print("\n✅ All tests passed!")
    
    return 0 if tester.tests_passed == tester.tests_run else 1

if __name__ == "__main__":
    sys.exit(main())
