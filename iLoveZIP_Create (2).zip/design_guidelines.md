{
  "brand": {
    "name": "MARKALUHURA",
    "person": "Dymas Alfin",
    "positioning": "Premium personal brand landing page (editorial portfolio × personal journal × digital playground). Minimal, monochrome, typography-driven. Curious multidisciplinary builder (competition, economics, investing, creativity, technology).",
    "voice": [
      "confident-not-arrogant",
      "curious",
      "precise",
      "editorial",
      "young",
      "high-contrast"
    ]
  },
  "design_personality": {
    "style_fusion": {
      "layout_principle": "Swiss editorial grid + generous whitespace + asymmetrical floating badges",
      "typography_principle": "Oversized grotesk display + uppercase metadata with tracking",
      "ui_principle": "Soft geometry (rounded-full / rounded-3xl) + 1px borders + subtle shadows",
      "motion_principle": "Cinematic but restrained: parallax layers, staggered reveals, hover-lift, cursor-follow preview"
    },
    "do_not": [
      "Do not make it look like a corporate resume site.",
      "Do not center-align the whole page.",
      "Do not use colorful gradients or decorative neon.",
      "Do not use purple (especially for accents).",
      "Do not overuse green; it is a status/availability accent only."
    ]
  },
  "color_system": {
    "palette_hex": {
      "white": "#FFFFFF",
      "off_white": "#F7F7F7",
      "light_gray": "#E5E5E5",
      "charcoal": "#111111",
      "accent_green": "#22C55E"
    },
    "semantic_tokens": {
      "--bg": "#FFFFFF",
      "--bg-muted": "#F7F7F7",
      "--surface": "#FFFFFF",
      "--surface-muted": "#F7F7F7",
      "--text": "#111111",
      "--text-muted": "rgba(17,17,17,0.68)",
      "--text-subtle": "rgba(17,17,17,0.52)",
      "--border": "rgba(17,17,17,0.12)",
      "--border-strong": "rgba(17,17,17,0.18)",
      "--shadow": "0 10px 30px rgba(17,17,17,0.08)",
      "--shadow-soft": "0 6px 18px rgba(17,17,17,0.06)",
      "--ring": "rgba(17,17,17,0.35)",
      "--status": "#22C55E",
      "--dark-bg": "#111111",
      "--dark-text": "#FFFFFF",
      "--dark-border": "rgba(255,255,255,0.14)",
      "--dark-muted": "rgba(255,255,255,0.72)"
    },
    "tailwind_mapping_notes": {
      "backgrounds": [
        "Use bg-white for primary reading areas",
        "Use bg-[#F7F7F7] for section breaks and footer",
        "Use bg-[#111111] only for Experience section and expanded accordion panels"
      ],
      "borders": [
        "Prefer border-black/10 (or border-[#111111]/10) for cards",
        "Use border-black/15 for nav pill and filter pills",
        "In dark sections use border-white/15"
      ],
      "text": [
        "Primary text: text-[#111111]",
        "Muted: text-[#111111]/70",
        "Subtle metadata: text-[#111111]/55",
        "Dark section: text-white and text-white/75"
      ]
    },
    "gradients_and_texture": {
      "policy": "No saturated gradients. If any gradient is used, it must be extremely subtle and only as a decorative overlay under 20% viewport.",
      "allowed": [
        {
          "name": "paper-wash",
          "usage": "Hero background overlay only (decorative, not behind dense text)",
          "css": "background: radial-gradient(1200px 600px at 20% 10%, rgba(17,17,17,0.06), transparent 60%), radial-gradient(900px 500px at 80% 30%, rgba(17,17,17,0.04), transparent 55%);"
        }
      ],
      "noise_overlay": {
        "usage": "Global subtle grain to avoid flatness (very low opacity)",
        "css_snippet": ".noise::before{content:'';position:absolute;inset:0;background-image:url('data:image/svg+xml,%3Csvg xmlns=%22http://www.w3.org/2000/svg%22 width=%22120%22 height=%22120%22%3E%3Cfilter id=%22n%22%3E%3CfeTurbulence type=%22fractalNoise%22 baseFrequency=%220.9%22 numOctaves=%222%22 stitchTiles=%22stitch%22/%3E%3C/filter%3E%3Crect width=%22120%22 height=%22120%22 filter=%22url(%23n)%22 opacity=%220.22%22/%3E%3C/svg%3E');opacity:0.05;pointer-events:none;mix-blend-mode:multiply;}"
      }
    }
  },
  "typography": {
    "font_pairing": {
      "display": "Plus Jakarta Sans (800–900)",
      "body": "Inter (400–600)",
      "fallback": "system-ui, -apple-system, Segoe UI, Roboto"
    },
    "loading": {
      "google_fonts": [
        "https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&family=Plus+Jakarta+Sans:wght@500;600;700;800;900&display=swap"
      ],
      "notes": "Import in index.css (top) or in public/index.html <link>. Use CSS variables --font-display and --font-body."
    },
    "type_scale_clamp": {
      "hero_display": "font-size: clamp(3.2rem, 7vw, 6.2rem); line-height: 0.92; letter-spacing: -0.04em;",
      "hero_outline_layer": "font-size: clamp(3.6rem, 8vw, 7.2rem); line-height: 0.9; letter-spacing: -0.05em;",
      "section_title": "font-size: clamp(1.6rem, 2.4vw, 2.4rem); line-height: 1.05; letter-spacing: -0.02em;",
      "statement_oversized": "font-size: clamp(2.2rem, 4.2vw, 4.2rem); line-height: 0.98; letter-spacing: -0.03em;",
      "body": "font-size: 1rem; line-height: 1.6;",
      "body_mobile": "font-size: 0.95rem; line-height: 1.65;",
      "meta_caps": "font-size: 0.75rem; letter-spacing: 0.18em; text-transform: uppercase;"
    },
    "stroke_text_technique": {
      "preferred": "Use CSS -webkit-text-stroke for outline layer; keep fill transparent.",
      "css": ".stroke-text{color:transparent;-webkit-text-stroke:1px rgba(17,17,17,0.55);text-stroke:1px rgba(17,17,17,0.55);} .stroke-text--dark{-webkit-text-stroke:1px rgba(255,255,255,0.55);}"
    },
    "selection_state": {
      "css": "::selection{background: rgba(34,197,94,0.22); color:#111111;}"
    }
  },
  "layout_and_grid": {
    "container": {
      "max_width": "1200px (content), allow hero typography to bleed full width",
      "padding": "px-5 sm:px-8 lg:px-10",
      "section_spacing": "py-16 sm:py-20 lg:py-28",
      "rhythm": "Use 2–3x more whitespace than typical portfolio; avoid dense stacks."
    },
    "grid": {
      "default": "12-col on lg, 6-col on md, 4-col on mobile",
      "work_grid": "2 columns on md+; 1 column on mobile; cards are large with generous gaps (gap-6 md:gap-8)",
      "hero_badges": "Absolute-positioned badges anchored left/right; on mobile they stack below hero portrait"
    },
    "anchors": {
      "ids": [
        "#top",
        "#about",
        "#work",
        "#exploring",
        "#experience",
        "#learning",
        "#philosophy",
        "#contact"
      ],
      "scroll_behavior": "Use smooth scrolling; offset for fixed navbar (scroll-mt-24 on sections)."
    }
  },
  "radius_shadow_border_tokens": {
    "radius": {
      "--r-pill": "9999px",
      "--r-card": "24px (rounded-3xl)",
      "--r-card-inner": "16px (rounded-2xl)",
      "--r-media": "20px"
    },
    "borders": {
      "thin": "1px solid rgba(17,17,17,0.12)",
      "thin_dark": "1px solid rgba(255,255,255,0.14)"
    },
    "shadows": {
      "nav": "0 10px 30px rgba(17,17,17,0.10)",
      "card_idle": "0 10px 30px rgba(17,17,17,0.06)",
      "card_hover": "0 18px 50px rgba(17,17,17,0.10)"
    }
  },
  "motion": {
    "libraries": {
      "required": [
        {
          "name": "framer-motion",
          "install": "npm i framer-motion",
          "usage": "Use for scroll-triggered reveals, staggered text, accordion height animation, hover lift. Respect prefers-reduced-motion."
        }
      ],
      "optional": [
        {
          "name": "react-intersection-observer",
          "install": "npm i react-intersection-observer",
          "usage": "Simplify reveal triggers for sections and timeline chapters."
        }
      ]
    },
    "timings": {
      "fast": "120ms",
      "base": "180ms",
      "slow": "320ms",
      "reveal": "600–900ms"
    },
    "easings": {
      "standard": "cubic-bezier(0.2, 0.8, 0.2, 1)",
      "lift": "cubic-bezier(0.16, 1, 0.3, 1)",
      "accordion": "cubic-bezier(0.22, 1, 0.36, 1)"
    },
    "micro_interactions": {
      "buttons": {
        "hover": "bg shifts slightly (black→black/90), subtle shadow increase, icon translate-x-1",
        "press": "scale-[0.98]",
        "focus": "ring-2 ring-black/30 ring-offset-2 ring-offset-white"
      },
      "pills": {
        "hover": "border-black/25 + bg-black/[0.03]",
        "active": "bg-black text-white"
      },
      "cards": {
        "hover": "translate-y-[-4px] + shadow to card_hover + image scale-105 + arrow translate-x-1",
        "metadata": "fade in (opacity 0→1) + slight y translate"
      },
      "parallax": {
        "hero_layers": "Background wordmark moves slower (0.35x), outline headline medium (0.6x), portrait fastest (1.0x). Disable on reduced motion."
      }
    },
    "reduced_motion": {
      "policy": "If prefers-reduced-motion: disable parallax transforms, reduce reveal durations to 0–120ms, keep opacity-only transitions."
    }
  },
  "imagery": {
    "treatment": {
      "rule": "All photos grayscale + high contrast; avoid color. Use CSS filter: grayscale(1) contrast(1.05).",
      "portrait": "Use provided cutout PNG centered in hero; add subtle shadow behind cutout (very soft)."
    },
    "image_urls": {
      "hero_portrait_placeholder": [
        {
          "category": "hero",
          "description": "Fallback grayscale portrait if provided asset missing",
          "url": "https://images.unsplash.com/photo-1520975958225-1f6f1f7f1f7b?auto=format&fit=crop&w=1200&q=80"
        }
      ],
      "work_thumbnails": [
        {
          "category": "work",
          "description": "Minimal editorial desk / screen (use as grayscale thumbnail)",
          "url": "https://images.unsplash.com/photo-1521737604893-d14cc237f11d?auto=format&fit=crop&w=1600&q=80"
        },
        {
          "category": "work",
          "description": "Notebook / planning texture (use as grayscale thumbnail)",
          "url": "https://images.unsplash.com/photo-1455390582262-044cdead277a?auto=format&fit=crop&w=1600&q=80"
        }
      ],
      "exploring_preview": [
        {
          "category": "exploring",
          "description": "Abstract monochrome texture for accordion preview",
          "url": "https://images.unsplash.com/photo-1526481280695-3c687fd5432c?auto=format&fit=crop&w=1600&q=80"
        }
      ],
      "learning_photos": [
        {
          "category": "learning",
          "description": "Conference / talk audience (grayscale)",
          "url": "https://images.unsplash.com/photo-1540575467063-178a50c2df87?auto=format&fit=crop&w=1600&q=80"
        }
      ]
    }
  },
  "components": {
    "component_path": {
      "navbar": [
        "/app/frontend/src/components/ui/navigation-menu.jsx",
        "/app/frontend/src/components/ui/sheet.jsx",
        "/app/frontend/src/components/ui/button.jsx",
        "/app/frontend/src/components/ui/badge.jsx",
        "/app/frontend/src/components/ui/separator.jsx"
      ],
      "hero": [
        "/app/frontend/src/components/ui/button.jsx",
        "/app/frontend/src/components/ui/badge.jsx",
        "/app/frontend/src/components/ui/aspect-ratio.jsx"
      ],
      "about_timeline": [
        "/app/frontend/src/components/ui/card.jsx",
        "/app/frontend/src/components/ui/separator.jsx"
      ],
      "work_filters_and_grid": [
        "/app/frontend/src/components/ui/toggle-group.jsx",
        "/app/frontend/src/components/ui/badge.jsx",
        "/app/frontend/src/components/ui/card.jsx",
        "/app/frontend/src/components/ui/button.jsx"
      ],
      "exploring_accordion": [
        "/app/frontend/src/components/ui/accordion.jsx",
        "/app/frontend/src/components/ui/card.jsx"
      ],
      "experience_timeline": [
        "/app/frontend/src/components/ui/hover-card.jsx",
        "/app/frontend/src/components/ui/card.jsx",
        "/app/frontend/src/components/ui/separator.jsx"
      ],
      "learning_strip": [
        "/app/frontend/src/components/ui/scroll-area.jsx",
        "/app/frontend/src/components/ui/card.jsx",
        "/app/frontend/src/components/ui/badge.jsx"
      ],
      "footer_cta": [
        "/app/frontend/src/components/ui/button.jsx",
        "/app/frontend/src/components/ui/badge.jsx",
        "/app/frontend/src/components/ui/separator.jsx"
      ],
      "toast": [
        "/app/frontend/src/components/ui/sonner.jsx"
      ]
    },
    "button_system": {
      "variants": {
        "primary": {
          "look": "Charcoal pill with white text",
          "tailwind": "rounded-full bg-[#111111] text-white hover:bg-[#111111]/90 shadow-sm hover:shadow-md focus-visible:ring-2 focus-visible:ring-black/30 focus-visible:ring-offset-2 focus-visible:ring-offset-white",
          "icon_motion": "group-hover:translate-x-1 transition-transform duration-180"
        },
        "secondary": {
          "look": "White pill with border",
          "tailwind": "rounded-full bg-white text-[#111111] border border-black/15 hover:border-black/25 hover:bg-black/[0.03] shadow-sm focus-visible:ring-2 focus-visible:ring-black/30 focus-visible:ring-offset-2 focus-visible:ring-offset-white"
        },
        "ghost": {
          "look": "Text-only editorial link",
          "tailwind": "rounded-full bg-transparent text-[#111111] hover:bg-black/[0.03]"
        }
      },
      "sizes": {
        "sm": "h-9 px-4 text-sm",
        "md": "h-11 px-5 text-sm",
        "lg": "h-12 px-6 text-sm"
      }
    },
    "pill_badge": {
      "tailwind": "inline-flex items-center gap-2 rounded-full border border-black/15 bg-white/80 backdrop-blur px-3 py-1 text-[11px] tracking-[0.18em] uppercase text-[#111111]/80"
    }
  },
  "section_level_guidance": {
    "1_navbar": {
      "layout": "Fixed floating pill centered horizontally with max-w-[1100px]. On desktop show items inline; on mobile collapse into Sheet (hamburger).",
      "visual": "bg-[#111111] text-white, rounded-full, backdrop-blur (for subtle glass), thin border white/10, shadow.",
      "items": [
        "Status pill: green dot + Available for New Opportunities",
        "About, Work, Experience, Exploring, Contact",
        "CTA: Let's Talk"
      ],
      "interaction": {
        "hover": "Nav links: bg-white/10; CTA: slightly brighter",
        "scroll": "Add subtle border/blur increase after scrollY>8",
        "mobile": "Sheet slides from right; links are large tap targets (min-h-11)"
      },
      "data_testids": {
        "nav": "floating-navbar",
        "availability": "availability-status-pill",
        "mobile_menu_button": "mobile-nav-open-button",
        "cta": "navbar-lets-talk-button"
      }
    },
    "2_hero": {
      "composition": "Oversized headline 'MORE THAN ONE THING' with layered outline + filled text. Background watermark 'MARKALUHURA' behind portrait. Center cutout portrait. Left and right floating badges.",
      "stroke": "Outline layer uses .stroke-text; filled layer uses text-[#111111].",
      "parallax": "Use framer-motion useScroll + useTransform for 3 layers (watermark, headline, portrait).",
      "badges": {
        "left": "ECONOMICS STUDENT + short description + CTA 'Let's Connect →'",
        "right": "FORMER ATHLETE · INVESTOR · CREATOR · BUILDER + social icons"
      },
      "supporting_statement": "Below hero: 'I like learning things deeply...' as body text with max-w-prose.",
      "data_testids": {
        "hero": "hero-section",
        "hero_connect": "hero-lets-connect-button",
        "hero_social_linkedin": "hero-social-linkedin",
        "hero_social_instagram": "hero-social-instagram",
        "hero_social_tiktok": "hero-social-tiktok",
        "hero_social_github": "hero-social-github"
      }
    },
    "3_about": {
      "headline": "/ABOUT + I'VE NEVER REALLY BEEN JUST ONE THING.",
      "timeline": {
        "structure": "Horizontal journey with 5 chapters (01–05). On mobile becomes vertical stack with left border.",
        "chapter_card": "Rounded-3xl, border-black/10, bg-white, large number + title + 1–2 lines.",
        "connector": "Use Separator as thin line; animate progress on scroll (optional)."
      },
      "data_testids": {
        "about": "about-section",
        "chapter_01": "about-chapter-01",
        "chapter_05": "about-chapter-05"
      }
    },
    "4_selected_work": {
      "header": "Watermark 'WORK' behind section title; right aligned 'View All Work →' link.",
      "filters": "Use ToggleGroup as pill filters. Active = bg-black text-white.",
      "grid": "2-col large cards with rounded-3xl; image top with rounded-2xl; metadata row.",
      "hover_spec": {
        "card": "translate-y-[-4px] shadow increases",
        "image": "scale-105",
        "arrow": "translate-x-1",
        "meta": "opacity 0.7→1"
      },
      "data_testids": {
        "work": "work-section",
        "filters": "work-filter-toggle-group",
        "view_all": "work-view-all-button",
        "card": "work-card"
      }
    },
    "5_exploring": {
      "header": "/CURRENTLY EXPLORING — THINGS I'M CURIOUS ABOUT",
      "accordion": {
        "component": "shadcn Accordion",
        "collapsed": "White surface, border-black/10",
        "expanded": "bg-[#111111] text-white; right side preview image appears (hidden on mobile)",
        "animation": "Smooth height + opacity; chevron rotates"
      },
      "data_testids": {
        "exploring": "exploring-section",
        "accordion": "exploring-accordion",
        "item": "exploring-accordion-item"
      }
    },
    "6_experience": {
      "theme": "Dark section: bg-[#111111] text-white",
      "headline": "A COLLECTION OF EXPERIENCES, NOT JUST JOB TITLES.",
      "timeline": {
        "layout": "Vertical list with year markers; each row is a button-like item.",
        "hover_preview": "On hover, show floating image card near cursor using HoverCard or custom portal; keep subtle border-white/15 and shadow.",
        "motion": "Preview fades/zooms in (opacity + scale 0.98→1)."
      },
      "data_testids": {
        "experience": "experience-section",
        "timeline_item": "experience-timeline-item",
        "hover_preview": "experience-hover-preview"
      }
    },
    "7_learning": {
      "header": "/ALWAYS LEARNING",
      "strip": {
        "layout": "Horizontal scroll strip using ScrollArea; cards snap (snap-x snap-mandatory).",
        "card": "Rounded-3xl, border-black/10, grayscale photo, topic, date, takeaway.",
        "micro": "On hover: lift + photo scale; on touch: no hover, keep clear tap targets."
      },
      "data_testids": {
        "learning": "learning-section",
        "strip": "learning-horizontal-strip",
        "card": "learning-event-card"
      }
    },
    "8_philosophy": {
      "layout": "Whitespace-heavy statement section with oversized typography and scroll reveal.",
      "motion": "Staggered line reveal (opacity + y). Avoid heavy transforms.",
      "data_testids": {
        "philosophy": "philosophy-section"
      }
    },
    "9_footer_contact": {
      "theme": "Off-white bg (#F7F7F7) with strong black typography.",
      "cta": "Have an idea... + primary CTA 'Let's Talk →' (WhatsApp) + secondary mailto.",
      "signature": "DYMAS ALFIN / ECONOMICS · INVESTING · CREATING · BUILDING",
      "data_testids": {
        "contact": "contact-section",
        "whatsapp": "footer-whatsapp-cta",
        "email": "footer-email-link"
      }
    }
  },
  "implementation_notes_react_js": {
    "file_conventions": "Project uses .js (not .tsx). Keep components in JS, use named exports for components and default export for page.",
    "global_css": {
      "index_css_updates": [
        "Import Google Fonts",
        "Set body font-family to var(--font-body)",
        "Add .stroke-text utility",
        "Add selection + noise overlay helper"
      ],
      "avoid": [
        "Do not keep CRA default App.css centered header styles.",
        "Do not use transition: all."
      ]
    },
    "data_testid_rule": "All interactive and key informational elements MUST include data-testid in kebab-case (role-based).",
    "icons": {
      "library": "lucide-react",
      "notes": "Use icons for social links and arrows; no emoji icons."
    }
  },
  "accessibility": {
    "focus": "Visible focus rings on all interactive elements (ring-2 + ring-offset).",
    "contrast": "Ensure text on off-white meets AA; use charcoal for body text.",
    "reduced_motion": "Respect prefers-reduced-motion; disable parallax and large transforms.",
    "keyboard": "Accordion, filters, nav links must be keyboard navigable."
  },
  "instructions_to_main_agent": [
    "Replace CRA default App.css styles; do not center the app container.",
    "Implement single-page anchored sections with scroll-mt-24 and a fixed floating navbar.",
    "Use Plus Jakarta Sans for display statements and Inter for body; implement clamp-based type scale and stroke text utility.",
    "Use shadcn components listed in component_path; avoid raw HTML dropdowns/accordions.",
    "Implement motion with framer-motion: hero parallax, section reveals, accordion height animation, card hover lift.",
    "Keep palette strictly monochrome; green only for availability dot and subtle selection highlight.",
    "Apply grayscale filter to all images for consistency.",
    "Add data-testid to every button/link/filter/accordion trigger/timeline item and key text blocks (e.g., availability)."
  ],
  "general_ui_ux_design_guidelines": "    - You must **not** apply universal transition. Eg: `transition: all`. This results in breaking transforms. Always add transitions for specific interactive elements like button, input excluding transforms\n    - You must **not** center align the app container, ie do not add `.App { text-align: center; }` in the css file. This disrupts the human natural reading flow of text\n   - NEVER: use AI assistant Emoji characters like`🤖🧠💭💡🔮🎯📚🎭🎬🎪🎉🎊🎁🎀🎂🍰🎈🎨🎰💰💵💳🏦💎🪙💸🤑📊📈📉💹🔢🏆🥇 etc for icons. Always use **FontAwesome cdn** or **lucid-react** library already installed in the package.json\n\n **GRADIENT RESTRICTION RULE**\nNEVER use dark/saturated gradient combos (e.g., purple/pink) on any UI element.  Prohibited gradients: blue-500 to purple 600, purple 500 to pink-500, green-500 to blue-500, red to pink etc\nNEVER use dark gradients for logo, testimonial, footer etc\nNEVER let gradients cover more than 20% of the viewport.\nNEVER apply gradients to text-heavy content or reading areas.\nNEVER use gradients on small UI elements (<100px width).\nNEVER stack multiple gradient layers in the same viewport.\n\n**ENFORCEMENT RULE:**\n    • Id gradient area exceeds 20% of viewport OR affects readability, **THEN** use solid colors\n\n**How and where to use:**\n   • Section backgrounds (not content backgrounds)\n   • Hero section header content. Eg: dark to light to dark color\n   • Decorative overlays and accent elements only\n   • Hero section with 2-3 mild color\n   • Gradients creation can be done for any angle say horizontal, vertical or diagonal\n\n- For AI chat, voice application, **do not use purple color. Use color like light green, ocean blue, peach orange etc\n\n</Font Guidelines>\n\n- Every interaction needs micro-animations - hover states, transitions, parallax effects, and entrance animations. Static = dead. \n   \n- Use 2-3x more spacing than feels comfortable. Cramped designs look cheap.\n\n- Subtle grain textures, noise overlays, custom cursors, selection states, and loading animations: separates good from extraordinary.\n   \n- Before generating UI, infer the visual style from the problem statement (palette, contrast, mood, motion) and immediately instantiate it by setting global design tokens (primary, secondary/accent, background, foreground, ring, state colors), rather than relying on any library defaults. Don't make the background dark as a default step, always understand problem first and define colors accordingly\n    Eg: - if it implies playful/energetic, choose a colorful scheme\n           - if it implies monochrome/minimal, choose a black–white/neutral scheme\n\n**Component Reuse:**\n\t- Prioritize using pre-existing components from src/components/ui when applicable\n\t- Create new components that match the style and conventions of existing components when needed\n\t- Examine existing components to understand the project's component patterns before creating new ones\n\n**IMPORTANT**: Do not use HTML based component like dropdown, calendar, toast etc. You **MUST** always use `/app/frontend/src/components/ui/ ` only as a primary components as these are modern and stylish component\n\n**Best Practices:**\n\t- Use Shadcn/UI as the primary component library for consistency and accessibility\n\t- Import path: ./components/[component-name]\n\n**Export Conventions:**\n\t- Components MUST use named exports (export const ComponentName = ...)\n\t- Pages MUST use default exports (export default function PageName() {...})\n\n**Toasts:**\n  - Use `sonner` for toasts\"\n  - Sonner component are located in `/app/src/components/ui/sonner.tsx`\n\nUse 2–4 color gradients, subtle textures/noise overlays, or CSS-based noise to avoid flat visuals."
}
